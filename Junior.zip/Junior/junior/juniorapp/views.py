from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404
from .models import *

menu_old = ['Home', 'About', 'Portfolio', 'Contact', 'Blog']
menu = [{'title': 'Home', 'url_name': 'home'},
        {'title': 'About', 'url_name': 'about'},
        {'title': 'Portfolio', 'url_name': 'portfolio'},
        {'title': 'Contact', 'url_name': 'contact'},
        {'title': 'Blog', 'url_name': 'blog'},
         ]

def index(request):
    context = {'menu': menu_old, 'title': "Блог"}
    return render(request, 'juniorapp/index.html', context=context)

def blog(request):
    posts = Blog.objects.all()
    context = {'posts': posts, 'menu': menu, 'title': "Блог"}
    return render(request, 'juniorapp/blog.html', context=context)

def about(request):
    return render(request, 'juniorapp/about.html')

def contact(request):
    return render(request, 'juniorapp/contact.html', {'title': 'Контакты'})

def portfolio(request):
    return render(request, 'juniorapp/portfolio.html', {'title': 'Портфолио'})

def show_post(request, post_slug):
    post = get_object_or_404(Blog, slug=post_slug)
    context = {"post": post, "menu": menu, "title": post.title, "cat_selected": post.cat_id}
    return render(request, 'juniorapp/post.html', context=context)
