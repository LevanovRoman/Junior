from django.apps import AppConfig


class JuniorappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'juniorapp'
    verbose_name = "Блог"
